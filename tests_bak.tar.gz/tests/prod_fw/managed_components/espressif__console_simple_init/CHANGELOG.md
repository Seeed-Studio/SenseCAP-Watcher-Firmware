# Changelog

## [1.1.0](https://github.com/espressif/esp-protocols/commits/console_simple_init-v1.1.0)

### Features

- Added runtime component registration support in console_simple_init ([057873c1](https://github.com/espressif/esp-protocols/commit/057873c1))

## [1.0.2](https://github.com/espressif/esp-protocols/commits/console_simple_init-v1.0.2)

### Bug Fixes

- Fixed bump version check in publish-docs yml ([e834d47](https://github.com/espressif/esp-protocols/commit/e834d47))

## [1.0.1](https://github.com/espressif/esp-protocols/commits/console_simple_init-v1.0.1)

### Bug Fixes

- Fixed versioning, publishing and changelog generation ([3081f1a69c](https://github.com/espressif/esp-protocols/commit/3081f1a69c))

## [1.0.0](https://github.com/espressif/esp-protocols/commits/console_simple_init-v1.0.0)


### Features

- [Added simple component for console initialization](https://github.com/espressif/esp-protocols/commit/1ac4e4177128a7b7188babd47d0e2bfa6bbb2517)
