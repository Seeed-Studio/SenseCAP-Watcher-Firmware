# Changelog

## [0.1.1](https://github.com/espressif/iperf-cmd/commits/v0.1.1)

### Features

- Supported `iperf` command.
- Supported specific option `--abort` to stop iperf.
- Supported register iperf hook functions - from [`espressif/iperf`]()
