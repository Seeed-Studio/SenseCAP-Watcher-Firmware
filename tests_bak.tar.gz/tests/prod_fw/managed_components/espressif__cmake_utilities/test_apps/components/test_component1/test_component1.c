#include <stdio.h>

int test_component1_version_major()
{
    return TEST_COMPONENT1_VER_MAJOR;
}

int test_component1_version_minor()
{
    return TEST_COMPONENT1_VER_MINOR;
}

int test_component1_version_patch()
{
    return TEST_COMPONENT1_VER_PATCH;
}
