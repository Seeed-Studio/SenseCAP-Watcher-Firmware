# Changelog

## [1.0.0](https://github.com/espressif/esp-protocols/commits/console_cmd_ping-v1.0.0)

### Features

- Added ping command to console component ([7babdeb9](https://github.com/espressif/esp-protocols/commit/7babdeb9))
